# RGX OTP

A brand-new Android application project. This project is independent of MotivBubble.

## Project identity
- App name: RGX OTP
- Package / application ID: `com.rgx.otp`
- Language: Kotlin
- Minimum Android: API 26 (Android 8.0)
- Compile / Target SDK: 35
- Java: 17
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9

## Build APK using GitHub Actions
1. Create a new, empty GitHub repository named `RGX-OTP`.
2. Upload the contents of this folder to the repository root (not the enclosing folder).
3. Open **Actions** and enable workflows if GitHub asks.
4. Run **Build RGX OTP APK**, or push to the `main` branch.
5. Open the successful workflow run and download `RGX-OTP-debug-APK` under Artifacts.

## Current implementation status
This is the clean, build-oriented starter project and initial home-screen shell. The 2FA engine, encrypted secret storage, spreadsheet database, clipboard paste workflows, CSV import/export, and floating overlay are not implemented yet. They will be added in separate tested phases.

## Security direction
TOTP secrets must be encrypted using Android Keystore-backed encryption. Never export TOTP secrets in CSV. Clipboard access must be user-initiated and visible; do not read clipboard silently in the background.
