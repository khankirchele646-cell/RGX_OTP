package com.rgx.otp

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 24, 39)
        window.navigationBarColor = Color.rgb(16, 24, 39)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
            setBackgroundColor(Color.rgb(16, 24, 39))
        }

        root.addView(TextView(this).apply {
            text = "RGX OTP"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }, match())

        root.addView(TextView(this).apply {
            text = "Your personal utility & authenticator"
            textSize = 14f
            setTextColor(Color.rgb(166, 180, 199))
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(28))
        }, match())

        addModule(root, "2FA AUTHENTICATOR", "Generate secure 6-digit codes")
        addModule(root, "MY SPREADSHEETS", "Organize information in A–Z sheets")
        addModule(root, "CSV MANAGER", "Import, export and share CSV files")
        addModule(root, "FLOATING BUBBLE", "Open your tools over other apps")

        root.addView(TextView(this).apply {
            text = "RGX OTP · Offline-first · Version 1.0.0"
            textSize = 11f
            setTextColor(Color.rgb(125, 143, 165))
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, 0)
        }, match())

        setContentView(root)
    }

    private fun addModule(parent: LinearLayout, title: String, subtitle: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(17), dp(18), dp(17))
            setBackgroundColor(Color.rgb(29, 42, 62))
        }
        card.addView(TextView(this).apply {
            text = title
            textSize = 16f
            setTextColor(Color.rgb(85, 214, 190))
            typeface = Typeface.DEFAULT_BOLD
        }, match())
        card.addView(TextView(this).apply {
            text = subtitle
            textSize = 13f
            setTextColor(Color.rgb(196, 207, 222))
            setPadding(0, dp(5), 0, 0)
        }, match())
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        params.bottomMargin = dp(12)
        parent.addView(card, params)
    }

    private fun match() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
